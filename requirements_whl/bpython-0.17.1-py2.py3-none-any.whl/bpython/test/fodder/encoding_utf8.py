# -*- coding: utf-8 -*-


def foo():
    """Test äöü"""
    pass
