bpython is a fancy interface to the Python
interpreter for Unix-like operating systems.

