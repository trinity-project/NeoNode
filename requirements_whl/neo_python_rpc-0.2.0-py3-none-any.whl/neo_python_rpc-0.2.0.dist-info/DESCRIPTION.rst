==============
neo-python-rpc
==============


.. image:: https://img.shields.io/pypi/v/neo-python-rpc.svg
        :target: https://pypi.python.org/pypi/neo-python-rpc

.. image:: https://img.shields.io/travis/CityOfZion/neo-python-rpc.svg
        :target: https://travis-ci.org/CityOfZion/neo-python-rpc

.. image:: https://readthedocs.org/projects/neo-python-rpc/badge/?version=latest
        :target: https://neo-python-rpc.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://coveralls.io/repos/github/CityOfZion/neo-python-rpc/badge.svg?branch=master
        :target: https://coveralls.io/github/CityOfZion/neo-python-rpc?branch=master
        :alt: Coverage Status

A Python RPC Client for the NEO Blockchain


* Free software: MIT license
* Documentation: https://neo-python-rpc.readthedocs.io.


Features
--------

A lightweight RPC Client for the NEO Blockchain



