
Verification = b'\x00'
Application = b'\x10'
