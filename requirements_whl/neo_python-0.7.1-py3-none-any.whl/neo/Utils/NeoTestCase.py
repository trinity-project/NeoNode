from unittest import TestCase


class NeoTestCase(TestCase):

    pass
