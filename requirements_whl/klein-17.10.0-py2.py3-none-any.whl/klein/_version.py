"""
Provides klein version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update klein` to change this file.

from incremental import Version

__version__ = Version('klein', 17, 10, 0)
__all__ = ["__version__"]
