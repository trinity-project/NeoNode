class CoverallsException(Exception):
    pass
