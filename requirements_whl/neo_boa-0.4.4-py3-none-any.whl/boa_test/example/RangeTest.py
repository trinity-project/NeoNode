
from boa.builtins import range


def Main():

    a = range(100, 120)

    return a
