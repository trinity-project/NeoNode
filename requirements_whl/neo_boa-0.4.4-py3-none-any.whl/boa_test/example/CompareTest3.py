
def Main():

    a = 3

    b = 2

    m = 0

    if a < b:
        print("lt")

    else:

        print("Gt")
        m = 4

    print("ok!!")

    return m
