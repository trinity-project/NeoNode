# tested


def Main():

    a = 1
    b = 2
    c = a + b

    return c
