

def Main():

    d = {}

    d['a'] = 4
    d[13] = 3

    d['mydict'] = {}

    return d['mydict']
