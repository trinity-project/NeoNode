# tested


def Main(index):

    j = 3
    arr = [1, j + 3, 3, 4, gethting(), 6, 7, 8, 9]

    m = arr[index]

    return m


def gethting():

    return 8
