# tested


def Main(a, b):

    if a == b:

        return True

    return False
