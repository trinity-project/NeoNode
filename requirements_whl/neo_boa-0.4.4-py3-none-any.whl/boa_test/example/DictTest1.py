

def Main():

    d = {}

    d['a'] = 4
    d[13] = 3

    return d
