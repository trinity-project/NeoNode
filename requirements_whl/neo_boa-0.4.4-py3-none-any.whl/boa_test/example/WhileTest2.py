# tested


def Main():

    j = 3
    while j < 8:
        j = j + 1

        if j == 6:
            break

    return j
