# tested


def Main(b1, b2):

    q = 4

    c2 = add_things(b1, b2)

    return q + c2


def add_things(a, b):

    result = a + b

    return result
