# tested


def Main():

    # lets have fun

    m = [[1, 2, 3], 'fun', 'cool', ['a', 'b', 'c']]

    answer = m[0]

    sub = m[3]

    sublen = len(sub)
    print(sublen)
    subitem = sub[0]
    print(subitem)

    return answer
