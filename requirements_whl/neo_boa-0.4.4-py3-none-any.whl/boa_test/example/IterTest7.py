# tested

from boa.builtins import range


def Main():

    count = 0

    for i in range(0, 12):
        count += 1

    return count
