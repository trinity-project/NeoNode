# tested


def Main(a, b):

    if a > b:

        return 3

    return 2
