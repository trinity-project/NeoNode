

def Main(operation):

    if operation == 1:
        return operation + 1

    elif operation == 2:
        return operation + 1

    elif operation == 3:
        return operation + 1

    elif operation == 4:
        return operation + 1

    elif operation == 5:
        return operation + 1

    elif operation == 6:
        return operation + 1

    elif operation == 7:
        return operation + 1

    elif operation == 8:
        return operation + 1

    elif operation == 9:
        return operation + 1

    elif operation == 10:
        return operation + 1

    elif operation == 11:
        return operation + 1

    elif operation == 12:
        return operation + 1

    elif operation == 13:
        return operation + 1

    elif operation == 14:
        return operation + 1

    elif operation == 15:
        return operation + 1

    elif operation == 16:
        return operation + 1

    elif operation == 17:
        return operation + 1

    elif operation == 18:
        return operation + 1

    return -1
