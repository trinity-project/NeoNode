# tested


def Main():
    """

    :return:
    """
    m = [16, 2, 3, 4]

    m.remove(1)

    return m
