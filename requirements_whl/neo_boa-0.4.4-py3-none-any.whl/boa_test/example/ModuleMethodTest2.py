
BLAH = 10 * 300

# This wont work
# BLAH2 = BLAH * 100


def Main():

    m = 3

    j = m + BLAH

    return j
