# tested


def Main(m):

    c = m + 2

    return c
