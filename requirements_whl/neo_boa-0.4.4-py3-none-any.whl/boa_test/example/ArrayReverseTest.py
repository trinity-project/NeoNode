# tested


def Main():

    m = [1, 2, 4, 'blah']

    m.reverse()

#    Notify(m)

#    m.reverse()

    return m[0]
