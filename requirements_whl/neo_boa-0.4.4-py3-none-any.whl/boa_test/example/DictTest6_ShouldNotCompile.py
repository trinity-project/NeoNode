# tested


def Main():

    # this file should/does not compile

    q = 3

    return {'a': 1, 'b': 2}  # dictionaries must be declared before use
