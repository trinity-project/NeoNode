# tested


def Main(j):

    if j == 4:

        raise Exception('hello')

    return True
