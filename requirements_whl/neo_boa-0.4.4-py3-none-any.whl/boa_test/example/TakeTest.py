# tested

from boa.builtins import take


def Main(amount):

    str1 = 'helloworld1234567'

    str2 = take(str1, amount)

    return str2
