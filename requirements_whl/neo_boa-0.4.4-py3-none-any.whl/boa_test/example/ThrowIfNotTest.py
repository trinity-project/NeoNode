# tested

from boa.builtins import throw_if_null


def Main(x1):

    throw_if_null(x1)

    return True
