

CONST = 8
OTHERCONTS = 1232

WHAT = 5


def Main():
    """

    :return:
    """
    print("do main?")
    j = CONST

    b = bleh()

    return CONST + OTHERCONTS + WHAT + b + j


def bleh():
    """

    :return:
    """
    return 2 + WHAT
