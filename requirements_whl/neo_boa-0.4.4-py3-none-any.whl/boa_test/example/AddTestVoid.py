# tested


def Main(m):

    c = m + 2
