# tested


def Main():

    j = 3
    while j < 6:
        j = j + 1

    return j
