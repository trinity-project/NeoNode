
def IterNext():
    pass


def IterKey():
    pass


def IterValue():
    pass
