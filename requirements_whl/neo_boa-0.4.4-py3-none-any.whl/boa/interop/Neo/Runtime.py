

def GetTrigger():
    """

    """
    pass


def CheckWitness(hash_or_pubkey):
    """

    :param hash_or_pubkey:
    """
    pass


def Log(message):
    """

    :param message:
    """
    pass


def Notify(arg):
    """

    :param arg:
    """
    pass


def GetTime():
    """
    returns timestamp of most recent block

    """
    pass


def Serialize(item):
    """
    Serializes an item into a bytearray
    """
    pass


def Deserialize(item):
    """
    Deserializes an item from a bytearray
    """
    pass
