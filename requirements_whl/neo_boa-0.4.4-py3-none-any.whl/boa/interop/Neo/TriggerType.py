
def Verification():
    """

    :return:
    """
    pass


def VerificationR():
    """

    :return:
    """
    pass


def Application():
    """

    :return:
    """
    pass


def ApplicationR():
    """

    :return:
    """
    pass
