
class TransactionAttribute:

    @property
    def Usage(self):
        """

        :return:
        """
        return GetUsage(self)

    @property
    def Data(self):
        """

        :return:
        """
        return GetData(self)


def GetUsage(transaction_attr):
    """

    :param transaction_attr:
    """
    pass


def GetData(transaction_attr):
    """

    :param transaction_attr:
    """
    pass
