
class Validator:
    pass


def Register(pubkey):
    """

    :param pubkey:
    """
    pass
