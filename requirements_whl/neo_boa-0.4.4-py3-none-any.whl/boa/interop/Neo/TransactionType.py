
def MinerTransaction():
    pass


def IssueTransaction():
    pass


def ClaimTransaction():
    pass


def EnrollmentTransaction():
    pass


def VotingTransaction():
    pass


def RegisterTransaction():
    pass


def ContractTransaction():
    pass


def StateTransaction():
    pass


def AgencyTransaction():
    pass


def PublishTransaction():
    pass


def InvocationTransaction():
    pass
