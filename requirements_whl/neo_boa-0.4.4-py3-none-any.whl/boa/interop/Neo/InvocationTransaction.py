
class InvocationTransaction:

    @property
    def Script(self):
        """

        :return:
        """
        return GetScript(self)


def GetScript(invocation_transaction):
    """

    :param invocation_transaction:
    """
    pass
