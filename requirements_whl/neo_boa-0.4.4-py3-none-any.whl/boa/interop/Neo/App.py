
def RegisterAppCall(smart_contract_hash, *args):
    """

    :param smart_contract_hash:
    :param args:
    """
    pass


def DynamicAppCall(smart_contract_hash, *args):
    """

    :param smart_contract_hash:
    :param args:
    """
    pass
