

def GetHeight():
    """

    """
    pass


def GetHeader(height_or_hash):
    """

    :param height_or_hash:
    """
    pass


def GetBlock(height_or_hash):
    """

    :param height_or_hash:
    """
    pass


def GetTransaction(hash):
    """

    :param hash:
    """
    pass


def GetAccount(script_hash):
    """

    :param script_hash:
    """
    pass


def GetValidators():
    """

    """
    pass


def GetAsset(asset_id):
    """

    :param asset_id:
    """
    pass


def GetContract(script_hash):
    """

    :param script_hash:
    """
    pass
