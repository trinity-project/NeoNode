

def GetContext():
    """

    """
    pass


# def CurrentContext():
#    return GetContext()

def Get(context, key):
    """

    :param context:
    :param key:
    """
    pass


def Put(context, key, value):
    """

    :param context:
    :param key:
    :param value:
    """
    pass


def Find(ctx, needle):
    """

    :param context:
    :param needle:
    """
    pass


def Delete(context, key):
    """

    :param context:
    :param key:
    """
    pass
