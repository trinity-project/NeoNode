

def RegisterAction(event_name, *args):
    """

    :param event_name:
    :param args:
    """
    pass
