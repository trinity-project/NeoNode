
class SmartContract:

    def Sha1(data):
        """

        """
        pass

    def Sha256(data):
        """

        """
        pass

    def Hash160(data):
        """

        """
        pass

    def Hash256(data):
        """

        """
        pass

    def VerifySignature(pubkey, signature):
        """

        :param signature:
        """
        pass
