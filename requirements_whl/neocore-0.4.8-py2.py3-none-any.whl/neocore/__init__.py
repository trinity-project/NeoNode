# -*- coding: utf-8 -*-

"""Top-level package for neo-python-core."""

__author__ = """City of Zion"""
__version__ = '0.4.8'
